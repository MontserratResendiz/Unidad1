package com.example.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText n1, n2;
    private TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        n1 = findViewById(R.id.n1);
        n2 = findViewById(R.id.n2);
        result = findViewById(R.id.result);

    }

    public void OpeSuma(View view){

        int num1, num2;
        int Osuma;

        num1 = Integer.parseInt(n1.getText().toString());

        num2 = Integer.parseInt(n2.getText().toString());

        Osuma = num1 + num2;

        result.setText("="+Osuma);

    }

    public void OpeResta(View view){

        int num1, num2;
        int Oresta;

        num1 = Integer.parseInt(n1.getText().toString());

        num2 = Integer.parseInt(n2.getText().toString());

        Oresta = num1 - num2;

        result.setText("="+Oresta);

    }

    public void OpeMulti(View view){

        int num1, num2;
        int OMulti;

        num1 = Integer.parseInt(n1.getText().toString());

        num2 = Integer.parseInt(n2.getText().toString());

        OMulti = num1 * num2;

        result.setText("="+OMulti);

    }

    public void OpeDivi(View view){

        int num1, num2;
        int ODivi;

        num1 = Integer.parseInt(n1.getText().toString());

        num2 = Integer.parseInt(n2.getText().toString());

        ODivi = num1 / num2;

        result.setText("="+ODivi);

    }



    public void Limpiar(View view){

        n1.setText("");
        n2.setText("");
        result.setText("");

    }

}