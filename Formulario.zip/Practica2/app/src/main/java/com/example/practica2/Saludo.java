package com.example.practica2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Saludo extends AppCompatActivity {

    private TextView SaludoM;
            Bundle Datos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saludo);

        SaludoM = findViewById(R.id.SaludoM);
        Datos = getIntent().getExtras();

    }

    public void recibir(){
        Bundle extras = getIntent().getExtras();
        String d1 = extras.getString("nombre");
        String d2 = extras.getString("apellidopa");
        String d3 = extras.getString("apellidoma");

        SaludoM = (TextView) findViewById(R.id.SaludoM);
        SaludoM.setText(d1);

    }

    public void salir(View view){
        finish();
    }
}